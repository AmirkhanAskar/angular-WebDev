export interface Books{
  id: number;
  name: string;
  description: string;
  year: number;
  likes: number;
  image: string;
  author: string;
  category: string;
}
