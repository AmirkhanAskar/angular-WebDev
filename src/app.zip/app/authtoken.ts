export interface AuthToken {
  token: string;
}
